p1 = [0 0 0];
p2 = [2 2 0];
p3 = [2 0 0];
p3 = [1 0 0];
p3 = [1 -1 0];


dist = distPointToLineSegment(p3, p1, p2)

