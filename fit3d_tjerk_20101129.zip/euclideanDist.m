function dist = euclideanDist(p3,p2)
dist = sqrt(sum((p3-p2).^2));
